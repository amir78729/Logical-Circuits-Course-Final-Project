# LogicDesignProject-HealthcareSystem

This is the Logic Circuit Design Final Project, fall 2019 Semester at Tehran Polytechnic.
This project designed to test and score my student projects.
